<template>
  <div>
    <Navbar v-if="!esLogin" />
    <router-view />
  </div>
</template>

<script>
import Navbar from './components/Navbar.vue'

export default {
  components: { Navbar },

  computed: {
    esLogin() {
      return this.$route.path === '/'
    }
  }
}
</script>