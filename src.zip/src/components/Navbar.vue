<template>
  <nav class="navbar navbar-dark bg-dark px-4">
    <span class="navbar-brand">Deportes Store</span>

    <div>
      <router-link to="/productos" class="btn btn-outline-light me-2">
        Productos
      </router-link>

      <button class="btn btn-danger" @click="logout">
        Salir
      </button>
    </div>
  </nav>
</template>

<script>
export default {
  name: "Navbar",
  methods: {
    logout() {
      localStorage.removeItem('auth')
      this.$router.push('/')
    }
  }
}
</script>