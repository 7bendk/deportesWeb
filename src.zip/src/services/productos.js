export const productosBase = [
  {
    id: 1,
    nombre: "Balón de fútbol",
    precio: 300,
    imagen: "https://images.unsplash.com/photo-1517649763962-0c623066013b"
  },
  {
    id: 2,
    nombre: "Tenis deportivos",
    precio: 1200,
    imagen: "https://images.unsplash.com/photo-1528701800489-20be3c3a7c9e"
  },
  {
    id: 3,
    nombre: "Guantes de box",
    precio: 800,
    imagen: "https://images.unsplash.com/photo-1605296867304-46d5465a13f1"
  },
  {
    id: 4,
    nombre: "Mancuernas",
    precio: 600,
    imagen: "https://images.unsplash.com/photo-1599058917765-a780eda07a3e"
  }
]