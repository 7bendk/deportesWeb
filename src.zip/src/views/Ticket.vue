<template>
  <div class="container mt-5">
    <div class="ticket shadow">
      <h3 class="text-center">Ticket de compra</h3>

      <ul>
        <li v-for="p in carrito" :key="p.id">
          {{ p.nombre }} - ${{ p.precio }}
        </li>
      </ul>

      <hr>

      <h4>Total: ${{ total }}</h4>

      <button class="btn btn-dark w-100 mt-3" @click="imprimir">
        Imprimir
      </button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      carrito: []
    }
  },

  computed: {
    total() {
      return this.carrito.reduce((sum, p) => sum + Number(p.precio), 0)
    }
  },

  mounted() {
    this.carrito = JSON.parse(localStorage.getItem('carrito')) || []
  },

  methods: {
    imprimir() {
      window.print()
    }
  }
}
</script>

<style>
.ticket {
  background: white;
  padding: 20px;
  border-radius: 10px;
  max-width: 400px;
  margin: auto;
}
</style>