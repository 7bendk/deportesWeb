<template>
  <div class="container mt-4">

    <h2>Tienda</h2>

    <!-- FORMULARIO CRUD -->
    <div class="card p-3 mb-4">
      <input v-model="nuevo.nombre" class="form-control mb-2" placeholder="Nombre">
      <input v-model="nuevo.precio" class="form-control mb-2" placeholder="Precio">
      <input v-model="nuevo.imagen" class="form-control mb-2" placeholder="URL imagen">

      <button class="btn btn-success" @click="guardar">
        {{ editando ? 'Actualizar' : 'Agregar' }}
      </button>
    </div>

    <!-- PRODUCTOS -->
    <div class="row">
      <div class="col-md-3 mb-4" v-for="p in productos" :key="p.id">
        <div class="card h-100 shadow">
          <img :src="p.imagen" class="card-img-top">

          <div class="card-body text-center">
            <h5>{{ p.nombre }}</h5>
            <p>${{ p.precio }}</p>

            <button class="btn btn-primary w-100 mb-2" @click="agregarCarrito(p)">
              Comprar
            </button>

            <button class="btn btn-warning w-100 mb-2" @click="editar(p)">
              Editar
            </button>

            <button class="btn btn-danger w-100" @click="eliminar(p.id)">
              Eliminar
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- CARRITO -->
    <div class="cart-box">
      🛒 {{ carrito.length }}
      <button class="btn btn-success btn-sm" @click="irPago">
        Pagar
      </button>
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      productos: [],
      carrito: [],
      nuevo: { nombre: '', precio: '', imagen: '' },
      editando: false,
      idEdit: null
    }
  },

  mounted() {
    this.productos = JSON.parse(localStorage.getItem('productos')) || []
    this.carrito = JSON.parse(localStorage.getItem('carrito')) || []
  },

  methods: {
    guardar() {
      if (this.editando) {
        const index = this.productos.findIndex(p => p.id === this.idEdit)
        this.productos[index] = { ...this.nuevo, id: this.idEdit }
        this.editando = false
      } else {
        this.productos.push({
          ...this.nuevo,
          id: Date.now()
        })
      }

      localStorage.setItem('productos', JSON.stringify(this.productos))
      this.nuevo = { nombre: '', precio: '', imagen: '' }
    },

    editar(p) {
      this.nuevo = { ...p }
      this.editando = true
      this.idEdit = p.id
    },

    eliminar(id) {
      this.productos = this.productos.filter(p => p.id !== id)
      localStorage.setItem('productos', JSON.stringify(this.productos))
    },

    agregarCarrito(p) {
      this.carrito.push(p)
      localStorage.setItem('carrito', JSON.stringify(this.carrito))
    },

    irPago() {
      this.$router.push('/pago')
    }
  }
}
</script>

<style>
.cart-box {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: white;
  padding: 10px;
}
</style>