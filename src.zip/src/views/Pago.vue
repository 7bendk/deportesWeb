<template>
  <div class="container mt-5">
    <div class="card p-4 shadow-lg">
      <h3>Pago con tarjeta</h3>

      <div>
        <span v-if="tipo=='visa'" class="badge bg-primary">VISA</span>
        <span v-if="tipo=='mastercard'" class="badge bg-danger">MASTERCARD</span>
      </div>

      <form @submit.prevent="pagar">
        <input v-model="tarjeta.numero" @input="detectarTipo"
               class="form-control mb-2" placeholder="Número de tarjeta">

        <input v-model="tarjeta.nombre"
               class="form-control mb-2" placeholder="Nombre">

        <div class="row">
          <div class="col">
            <input v-model="tarjeta.fecha" class="form-control mb-2" placeholder="MM/AA">
          </div>
          <div class="col">
            <input v-model="tarjeta.cvv" class="form-control mb-2" placeholder="CVV">
          </div>
        </div>

        <div class="text-danger">{{ error }}</div>

        <button class="btn btn-success w-100">Pagar</button>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tarjeta: { numero:'', nombre:'', fecha:'', cvv:'' },
      tipo: '',
      error: ''
    }
  },

  methods: {
    detectarTipo() {
      if (this.tarjeta.numero.startsWith('4')) this.tipo = 'visa'
      else if (/^5[1-5]/.test(this.tarjeta.numero)) this.tipo = 'mastercard'
      else this.tipo = ''
    },

    validarLuhn(numero) {
      let suma = 0, alt = false
      for (let i = numero.length - 1; i >= 0; i--) {
        let n = parseInt(numero[i])
        if (alt) { n *= 2; if (n > 9) n -= 9 }
        suma += n
        alt = !alt
      }
      return suma % 10 === 0
    },

    pagar() {
      this.error = ''

      // Validaciones
      if (!this.validarLuhn(this.tarjeta.numero)) {
        this.error = 'Tarjeta inválida'
        return
      }

      if (!this.tarjeta.nombre || !this.tarjeta.fecha || !this.tarjeta.cvv) {
        this.error = 'Completa todos los campos'
        return
      }

      // Obtener carrito
      const carrito = JSON.parse(localStorage.getItem('carrito')) || []

      if (carrito.length === 0) {
        this.error = 'Carrito vacío'
        return
      }

      // Calcular total
      const total = carrito.reduce((a, p) => a + Number(p.precio), 0)

      // Crear ticket
      const ticket = {
        fecha: new Date().toLocaleString(),
        productos: carrito,
        total
      }

      // Guardar ticket
      localStorage.setItem('ticket', JSON.stringify(ticket))

      // Limpiar carrito
      localStorage.removeItem('carrito')

      // Redirigir
      this.$router.push('/ticket')
    }
  }
}
</script>