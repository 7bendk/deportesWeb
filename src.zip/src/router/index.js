router.beforeEach((to, from, next) => {
  const auth = localStorage.getItem('auth')

  if (to.path !== '/' && !auth) {
    next('/')
  } else {
    next()
  }
})